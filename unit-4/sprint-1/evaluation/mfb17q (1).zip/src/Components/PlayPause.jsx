// Write Code here
// import {useState} from "react"

export default function PlayPause() {
  return (
    <div>
      <h1>The state is paused</h1>
      <button>paused</button>
    </div>
  );
}
