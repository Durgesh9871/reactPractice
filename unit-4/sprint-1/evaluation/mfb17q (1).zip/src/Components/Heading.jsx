// Write code here
export default function Heading() {
  return (
    <div>
      <h1>Masai School</h1>
    </div>
  );
}
